# path = "Anexo_Arquivo_Dados_Projeto_Logica_e_programacao_de_computadores.csv"
