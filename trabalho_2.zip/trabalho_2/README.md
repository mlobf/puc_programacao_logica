# Puc_programacao_logica Parte Dois
Segundo trabalho de logica de programacao
Python 3.12.3 com venv e libs no requirements.txt
Para iniciar:
1- Criar o ambiente virtual e instalar as libs.
=> python3.12 -m venv myvenv && pip3.12 install -r requirements.txt
2- Rodar o programa
=>python3.12 main.py


